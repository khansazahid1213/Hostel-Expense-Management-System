require("dotenv").config();
const express = require("express");
const Stripe = require("stripe");
const app = express();

if (!process.env.STRIPE_SECRET_KEY) {
  console.error("❌ STRIPE_SECRET_KEY is missing. Set it in your .env file.");
  process.exit(1);
}
if (!process.env.LARAVEL_API_URL || !process.env.INTERNAL_API_SECRET) {
  console.error("❌ LARAVEL_API_URL / INTERNAL_API_SECRET missing from .env.");
  process.exit(1);
}
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

app.post(
  "/webhook",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    const sig = req.headers["stripe-signature"];
    let event;

    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET
      );
    } catch (err) {
      console.error("Webhook signature verification failed:", err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === "payment_intent.succeeded") {
      const paymentIntent = event.data.object;
      console.log("✅ Payment succeeded:", paymentIntent.id, paymentIntent.metadata);

      try {
        const resp = await fetch(`${process.env.LARAVEL_API_URL}/api/internal/stripe/mark-paid`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Internal-Secret": process.env.INTERNAL_API_SECRET,
          },
          body: JSON.stringify({
            payment_intent_id: paymentIntent.id,
            bill_id: paymentIntent.metadata.bill_id,
            student_id: paymentIntent.metadata.student_id,
            amount_pkr: paymentIntent.metadata.amount_pkr, // set below
          }),
        });

        if (!resp.ok) {
          const body = await resp.text();
          console.error("⚠️ Laravel rejected mark-paid:", resp.status, body);
          // Return 500 so Stripe retries this webhook automatically
          return res.status(500).json({ received: false });
        }
        console.log("✅ Bill marked paid in Laravel:", paymentIntent.metadata.bill_id);
      } catch (err) {
        console.error("⚠️ Failed to reach Laravel:", err.message);
        return res.status(500).json({ received: false }); // triggers Stripe retry
      }
    }

    res.json({ received: true });
  }
);

app.use(express.json());

app.post("/create-payment-intent", async (req, res) => {
  try {
    const {
      amount,       // USD cents
      amountPkr,    // ✅ original PKR amount, kept for reconciliation
      billId,
      studentId,
      currency = "usd",
    } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ success: false, error: "A valid amount is required" });
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount),
      currency,
      automatic_payment_methods: { enabled: true },
      metadata: {
        bill_id: billId || "unknown",
        student_id: studentId || "unknown",
        amount_pkr: amountPkr || "0",
        platform: "hostelhub",
      },
    });

    res.json({
      success: true,
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
    });
  } catch (error) {
    console.error("Payment intent error:", error.message);
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get("/payment-intent/:id", async (req, res) => {
  try {
    const paymentIntent = await stripe.paymentIntents.retrieve(req.params.id);
    res.json({
      success: true,
      status: paymentIntent.status,
      amount: paymentIntent.amount,
      currency: paymentIntent.currency,
      metadata: paymentIntent.metadata,
    });
  } catch (error) {
    console.error("Retrieve error:", error.message);
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get("/", (req, res) => {
  res.json({ message: "HostelHub Stripe API Server" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 HostelHub Stripe Server running on port ${PORT}`);
});